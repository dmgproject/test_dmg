package com.dmg.jsp.member.model.exception;

public class MemberException extends Exception{

	public MemberException() {
		super();
	}
	
	public MemberException(String msg) {
		super(msg);
	}
}
