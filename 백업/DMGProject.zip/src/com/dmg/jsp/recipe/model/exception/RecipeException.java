package com.dmg.jsp.recipe.model.exception;

public class RecipeException extends Exception{

	public RecipeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RecipeException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
}
