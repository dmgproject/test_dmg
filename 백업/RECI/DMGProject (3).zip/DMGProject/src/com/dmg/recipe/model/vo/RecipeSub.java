package com.dmg.recipe.model.vo;

import java.io.Serializable;

public class RecipeSub implements Serializable {
	private int renum;
	private String resub;

	public RecipeSub() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RecipeSub(String resub) {
		super();
		this.resub = resub;
	}

	@Override
	public String toString() {
		return "RecipeSub [renum=" + renum + ", resub=" + resub + "]";
	}

	public int getRenum() {
		return renum;
	}

	public void setRenum(int renum) {
		this.renum = renum;
	}

	public String getResub() {
		return resub;
	}

	public void setResub(String resub) {
		this.resub = resub;
	}
}
