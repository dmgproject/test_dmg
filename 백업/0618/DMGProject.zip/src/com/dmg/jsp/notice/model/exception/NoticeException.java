package com.dmg.jsp.notice.model.exception;
/*
 * DMG.COM 
 * 2019.06.01
 */
public class NoticeException extends Exception {
	
	public NoticeException () {
		super();
	}
	
	public NoticeException(String msg) {
		super(msg);
	}

}
